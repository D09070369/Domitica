import { useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";
import "./App.css";

const INITIAL_STATE = {
  entrada: false,
  cocina: false,
  bano: false,
  cuarto: false,
  foco: false,
  ventilador: false,
  puerta: 0,
  tempDHT: null,
  humedad: null,
  tempLM35: null,
  agua: false,
  distancia: 999,
  hayPersonaCerca: false,
  ultimaActualizacion: null
};

function App() {
  const [serverIP, setServerIP] = useState(localStorage.getItem("serverIP") || "");
  const [inputIP, setInputIP] = useState(localStorage.getItem("serverIP") || "");
  const [serverReachable, setServerReachable] = useState(false);
  const [socketConnected, setSocketConnected] = useState(false);
  const [socket, setSocket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMsg, setNewMsg] = useState("");
  const [devices, setDevices] = useState([]);
  const [estado, setEstado] = useState(INITIAL_STATE);

  const messagesEndRef = useRef(null);

  const isConnected = useMemo(
    () => serverReachable && socketConnected,
    [serverReachable, socketConnected]
  );

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const checkServer = async (ip) => {
    const trimmed = ip.trim();
    if (!trimmed) return false;

    try {
      const response = await fetch(`http://${trimmed}:3000/health`);
      return response.ok;
    } catch {
      return false;
    }
  };

  const connectToServer = async (ip) => {
    const trimmed = ip.trim();
    if (!trimmed) return;

    const ok = await checkServer(trimmed);

    if (!ok) {
      setServerReachable(false);
      setSocketConnected(false);
      return;
    }

    localStorage.setItem("serverIP", trimmed);
    setInputIP(trimmed);
    setServerIP(trimmed);
    setServerReachable(true);
  };

  useEffect(() => {
    const savedIP = localStorage.getItem("serverIP") || "";
    if (!savedIP) return;

    (async () => {
      const ok = await checkServer(savedIP);
      if (ok) {
        setInputIP(savedIP);
        setServerIP(savedIP);
        setServerReachable(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!serverIP || !serverReachable) return;

    const s = io(`http://${serverIP}:3000`, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000
    });

    setSocket(s);

    s.on("connect", () => {
      setSocketConnected(true);
      s.emit("device:hello", { deviceName: "Frontend React" });
    });

    s.on("disconnect", () => {
      setSocketConnected(false);
    });

    s.on("init", (payload) => {
      if (payload?.estado) setEstado(payload.estado);
      if (Array.isArray(payload?.devices)) setDevices(payload.devices);
      if (Array.isArray(payload?.messages)) setMessages(payload.messages);
    });

    s.on("estado", (nuevoEstado) => {
      setEstado((prev) => ({ ...prev, ...nuevoEstado }));
    });

    s.on("sensores", (sensores) => {
      setEstado((prev) => ({ ...prev, ...sensores }));
    });

    s.on("devices:update", (deviceList) => {
      setDevices(Array.isArray(deviceList) ? deviceList : []);
    });

    s.on("chat:message", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    return () => {
      s.disconnect();
      setSocket(null);
      setSocketConnected(false);
    };
  }, [serverIP, serverReachable]);

  const handleSendMessage = () => {
    if (!newMsg.trim() || !socket) return;
    socket.emit("chat:message", { text: newMsg.trim() });
    setNewMsg("");
  };

  return (
    <div className="app-shell">
      <h1>Control IoT con LLM</h1>

      <div className="card chat-container">
        <h2>Conectar al servidor</h2>

        <div className="chat-input">
          <input
            type="text"
            placeholder="Ingresa IP del servidor"
            value={inputIP}
            onChange={(e) => setInputIP(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && connectToServer(inputIP)}
          />
          <button onClick={() => connectToServer(inputIP)}>Conectar</button>
        </div>

        <div className="chat-info-box">
          <p><strong>Servidor:</strong> {serverIP || "Sin configurar"}</p>
          <p><strong>Conexión:</strong> {isConnected ? "Activa" : "Desconectada"}</p>
          <p>
            <strong>Dispositivos:</strong>{" "}
            {devices.length === 0
              ? "Ninguno conectado"
              : devices.map((d) => d.deviceName).join(", ")}
          </p>
        </div>

        <div className="status-grid">
          <div className="status-box">Sala: <strong>{estado.entrada ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Cocina: <strong>{estado.cocina ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Baño: <strong>{estado.bano ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Cuarto: <strong>{estado.cuarto ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Foco: <strong>{estado.foco ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Ventilador: <strong>{estado.ventilador ? "ON" : "OFF"}</strong></div>
          <div className="status-box">Puerta: <strong>{estado.puerta}°</strong></div>
          <div className="status-box">Agua: <strong>{estado.agua ? "Sí" : "No"}</strong></div>
          <div className="status-box">Temp sala: <strong>{estado.tempDHT ?? "--"} °C</strong></div>
          <div className="status-box">Humedad: <strong>{estado.humedad ?? "--"} %</strong></div>
          <div className="status-box">Temp cocina: <strong>{estado.tempLM35 ?? "--"} °C</strong></div>
          <div className="status-box">Puerta cerca: <strong>{estado.hayPersonaCerca ? "Sí" : "No"}</strong></div>
        </div>

        <div className="chat-container">
          <h2>Chat</h2>

          <div className="chat-messages">
            {messages.map((m, idx) => (
              <div key={idx}>
                <strong>{m.user}:</strong> {m.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input">
            <input
              type="text"
              value={newMsg}
              onChange={(e) => setNewMsg(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder={isConnected ? "Escribe un mensaje..." : "Debes conectar al servidor"}
              disabled={!socket}
            />
            <button onClick={handleSendMessage} disabled={!socket}>
              Enviar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
