import json
import os

import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/chat")
MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:1.5b-instruct")

SYSTEM_PROMPT = """
Eres un asistente para proyectos IoT con Raspberry Pi.
Responde SIEMPRE en JSON valido con este formato exacto:
{
  "reply": "texto breve y claro para el usuario",
  "led_command": null
}

Si el usuario pide prender/apagar/cambiar LEDs, usa:
{
  "reply": "confirmacion breve",
  "led_command": {
    "white": true|false|null,
    "yellow": true|false|null,
    "blue": true|false|null
  }
}

Reglas:
- Solo usa las llaves white, yellow, blue.
- Usa null en una llave cuando no quieras cambiar ese LED.
- No agregues campos extras.
- No escribas markdown ni texto fuera del JSON.
""".strip()


class ChatIn(BaseModel):
    message: str


def _request_ollama(message: str, force_json: bool) -> dict:
    body = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message},
        ],
        "stream": False,
    }
    if force_json:
        body["format"] = "json"

    response = requests.post(
        OLLAMA_URL,
        json=body,
        timeout=120,
    )
    response.raise_for_status()
    return response.json()


def _extract_json_object(text: str):
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None

    json_candidate = text[start : end + 1]
    try:
        return json.loads(json_candidate)
    except json.JSONDecodeError:
        return None


def _coerce_led_value(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "on", "true", "encender", "prender"}:
            return True
        if normalized in {"0", "off", "false", "apagar"}:
            return False
    return None


def _sanitize_led_command(raw_command):
    if not isinstance(raw_command, dict):
        return None

    sanitized = {}
    for key in ("white", "yellow", "blue"):
        if key not in raw_command:
            continue
        coerced = _coerce_led_value(raw_command.get(key))
        if coerced is not None:
            sanitized[key] = coerced

    return sanitized or None


@app.post("/chat")
def chat(payload: ChatIn):
    try:
        data = _request_ollama(payload.message, force_json=True)
    except requests.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        if status_code == 400:
            try:
                data = _request_ollama(payload.message, force_json=False)
            except requests.RequestException as fallback_exc:
                raise HTTPException(status_code=502, detail=f"LLM request failed: {fallback_exc}") from fallback_exc
        else:
            raise HTTPException(status_code=502, detail=f"LLM request failed: {exc}") from exc
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"LLM request failed: {exc}") from exc

    content = (data.get("message") or {}).get("content", "").strip()
    if not content:
        return {"reply": "No se recibio respuesta del LLM.", "led_command": None}

    parsed = None
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        parsed = _extract_json_object(content)

    if not isinstance(parsed, dict):
        return {"reply": content, "led_command": None}

    reply = parsed.get("reply")
    if not isinstance(reply, str) or not reply.strip():
        reply = "Comando procesado."

    led_command = _sanitize_led_command(parsed.get("led_command"))
    return {"reply": reply.strip(), "led_command": led_command}
    
